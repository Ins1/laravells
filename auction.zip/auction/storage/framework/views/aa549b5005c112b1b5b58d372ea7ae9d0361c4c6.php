<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>


                    <h3>Create Users</h3>
                    <form action = "<?php echo e(url('user/create')); ?>" method = 'POST' enctype="multipart/form-data">
                        Full Name : <input type = 'text' name = 'fullname' class = 'form-control' value = "<?php echo e(old('fullname')); ?>" ><br>
                        Email : <input type = 'text' name = 'email' class = 'form-control' value = "<?php echo e(old('email')); ?>" ><br>
                        Contact : <input type = 'text' name = 'contact' class = 'form-control' value = "<?php echo e(old('contact')); ?>" ><br>
                        Address : <input type = 'text' name = 'address' class = 'form-control' value = "<?php echo e(old('address')); ?>" ><br>
                        Image : <input type = 'file' class = 'form-control' name = 'image' alt="No Image" /><br>
                        Password : <input type = 'password' name = 'password' class = 'form-control' ><br>
                        Confirm Password : <input type = 'password' name = 'password_confirmation' class = 'form-control' ><br>
                        User Type :
                        <select  class = 'form-control' name="userType">
                            <option value="admin">Admin</option>
                            <option value="Buyer">Buyer</option>
                            <option value="Seller">Seller</option>
                        </select><br>
                        <input type = 'hidden' name = '_token' value="<?php echo e(csrf_token()); ?>">
                        <input type = 'submit' class = 'btn btn-primary'/>

                    </form>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>