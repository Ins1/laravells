<?php $__env->startSection('content'); ?>


	<?php if(\Session::has('msg')): ?>
	<div class = 'alert alert-success'>
		<p><?php echo e(\Session::get('msg')); ?></p>
	</div></br>
	<?php endif; ?>

	<?php if($errors->any()): ?>
	<div class = 'alert alert-danger'>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($e); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>

<h3>Registration Form</h3>
<form action = "<?php echo e(url('user/register')); ?>" method = 'POST' enctype="multipart/form-data">
	Full Name : <input type = 'text' name = 'fullname' class = 'form-control' value = "<?php echo e(old('fullname')); ?>" ><br>
	Email : <input type = 'text' name = 'email' class = 'form-control' value = "<?php echo e(old('email')); ?>" ><br>
	Contact : <input type = 'text' name = 'contact' class = 'form-control' value = "<?php echo e(old('contact')); ?>" ><br>
	Address : <input type = 'text' name = 'address' class = 'form-control' value = "<?php echo e(old('address')); ?>" ><br>
	Image : <input type = 'file' name = 'image' class = 'form-control' ><br>
	Password : <input type = 'password' name = 'password' class = 'form-control' ><br>
	Confirm Password : <input type = 'password' name = 'password_confirmation' class = 'form-control' ><br>
	User Type :
    <select  class = 'form-control' name="userType">
       
        <option value="Buyer">Buyer</option>
        <option value="Seller">Seller</option>
    </select><br>
	<input type = 'hidden' name = '_token' value="<?php echo e(csrf_token()); ?>">
	<input type = 'submit' class = 'btn btn-primary'/>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>