<?php $__env->startSection('content'); ?>

<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Features Items</h2>

						<?php if(!$products->isEmpty()): ?>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">

								<?php //featured items contain products that are featured 6 ?>
										<div class="productinfo text-center">
											<img src="<?php echo e(asset('uploads/'.$value['image'])); ?>" alt="" />
											<h2>Rs. <?php echo e($value['price']); ?></h2>
											<p><?php echo e($value['product_code']); ?></p>
<!--											<?php if(Auth::check()): ?>-->
<!--											<a class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>-->
<!--											<?php endif; ?>-->
											<a href="<?php echo e(url('product/'.$value['id'])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-plus"></i>View Details</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>Rs. <?php echo e($value['price']); ?></h2>
												<p><?php echo e($value['product_code']); ?> </p>
<!--												<?php if(Auth::check()): ?>-->
<!--												<a data-productid = "<?php echo e($value['id']); ?>"  class="btn btn-default add-to-cart addtocart"><i class="fa fa-shopping-cart"></i>Add to cart</a>-->
<!--												<?php endif; ?>-->
												<a href="<?php echo e(url('product/'.$value['id'])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-plus"></i>View Details</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">

                                        <?php if($value['auction_date'] < date('Y-m-d')): ?>
                                                <li><i class="fa fa-plus-square" style="margin-left: 95px;"></i>Closed</li>
                                        <?php else: ?>
                                        <li ><i class="fa fa-plus-square" style="margin-left: 95px;"></i>Open</li>
                                        <?php endif; ?>
<!--									<?php if(Auth::check()): ?>-->
<!--										<li><a href="<?php echo e(url('wishlist/add/'.$value['id'])); ?>"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>-->
<!--									<?php endif; ?>-->
									</ul>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<div class = 'col-sm-12'>
							<p>No products found</p>
						</div>
						<?php endif; ?>

					</div><!--features_items-->
					<?php echo e($products->appends(request()->query())->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>