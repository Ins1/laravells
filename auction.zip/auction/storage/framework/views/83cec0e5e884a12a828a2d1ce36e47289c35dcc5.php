<?php $__env->startSection('content'); ?>



<h3>Contact Us</h3>
<form action = "<?php echo e(url('/contact')); ?>" method = 'POST'>
	Name : <input type = 'text' name = 'name' class = 'form-control' value = "<?php echo e(old('name')); ?>" ><br>
	Email : <input type = 'text' name = 'email' class = 'form-control' value = "<?php echo e(old('email')); ?>" ><br>
	Subject : <input type = 'text' name = 'subject' class = 'form-control' value="<?php echo e(old('subject')); ?>" ><br>
	Message : <textarea name="message" class="form-control" value="<?php echo e(old('message')); ?>"></textarea><br>
	<input type = 'hidden' name = '_token' value="<?php echo e(csrf_token()); ?>">
	<input type = 'submit' class = 'btn btn-primary'/>
</form>
					
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>