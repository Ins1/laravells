<!DOCTYPE html>
<html>
<head>
	<title>Marksheet</title>
</head>
<body>
<h2>Student Name: <?php echo e($student_name); ?></h2>
<h3>SNO : <?php echo e($sno); ?></h3>
<h2>Marks : </h2>
<h3>Java : <?php echo e($java); ?> </h3>

<h3>Status : <?php echo e($status); ?> </h3>
</body>
</html>