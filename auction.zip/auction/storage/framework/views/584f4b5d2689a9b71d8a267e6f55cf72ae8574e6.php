<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


<h3>Add a New Product</h3>

<form action = "<?php echo e(url('product/create')); ?>" method = 'POST' enctype="multipart/form-data">
    Product Code : <input type = 'text' class = 'form-control' name = 'pcode' value = "<?php echo e(old('pcode')); ?>" /><br>
	Artist name : <input type = 'text' class = 'form-control' name = 'aname' value = "<?php echo e(old('aname')); ?>" /><br>
	Created Date : <input type = 'date' class = 'form-control' name = 'cdate' value = "<?php echo e(old('cdate')); ?>" /><br>
	Auction Date : <input type = 'date' class = 'form-control' name = 'audate' value = "<?php echo e(old('audate')); ?>" /><br>
	Qty : <input type = 'text' class = 'form-control' name = 'qty' value = "<?php echo e(old('qty')); ?>"/><br>
	Price : <input type = 'text' class = 'form-control' name = 'price' value = "<?php echo e(old('price')); ?>"/><br>
	Image : <input type = 'file' class = 'form-control' name = 'image' /><br>

	Choose Category : <select class = 'form-control' name = 'categoryid' id="categoryid" onchange="applyFilter()">
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($value['id']); ?>" <?php if(old('categoryid') == $value['id']): ?> selected <?php endif; ?>><?php echo e($value['category_name']); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select><br>
    <p id="featured" hidden>Is Framed : Yes<input type = 'radio' name = 'featured' value = 'yes' <?php if(old('featured') == 'yes'): ?> checked <?php endif; ?>/>
        No<input type = 'radio' name = 'featured' value = 'no' <?php if(old('featured') == 'no'): ?> checked <?php endif; ?>/>
        <br><br></p>
    <p id="dimensions" hidden>Dimensions : <input type = 'text' class = 'form-control'  name = 'dimensions' value = "<?php echo e(old('dimensions')); ?>"/><br></p>
    <p id="weigth" hidden>Weigth : <input type = 'text' class = 'form-control'  name = 'weigth' value = "<?php echo e(old('weigth')); ?>"/><br></p>
    <p id="materials" hidden>Materials : <input type = 'text' class = 'form-control' name = 'materials' value = "<?php echo e(old('materials')); ?>"/><br></p>
    <p id="medium" hidden>Medium : <input type = 'text' class = 'form-control'   name = 'medium' value = "<?php echo e(old('medium')); ?>"/><br></p>
    <p id="type" hidden> Type : <input type = 'text' class = 'form-control'  name = 'type' value = "<?php echo e(old('type')); ?>"/><br></p>
    Detail : <textarea class = 'form-control' name = 'detail'><?php echo e(old('detail')); ?></textarea><br>
    <input type = 'hidden' name = 'usernam' value = '<?php echo e(Auth::user()->name); ?>' />
	<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
	<input type = 'submit' class = 'btn btn-primary' />

</form>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

    applyFilter();
    $("#categoryid").trigger('change');



    function applyFilter(){

        var value = $('#categoryid').val();
        if(value != null){
            if(value == 6 || value == 7){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden",false);
                $('#featured').prop("hidden",false);
                $('#type').prop("hidden","hidden");
                $('#weigth').prop("hidden","hidden");
                $('#materials').prop("hidden","hidden");
            }else if(value == 9){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden","hidden");
                $('#featured').prop("hidden","hidden");
                $('#type').prop("hidden",false);
                $('#weigth').prop("hidden","hidden");
                $('#materials').prop("hidden","hidden");
            }else if(value == 8 || value == 10){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden","hidden");
                $('#featured').prop("hidden","hidden");
                $('#type').prop("hidden","hidden");
                $('#weigth').prop("hidden",false);
                $('#materials').prop("hidden",false);
            }
        }
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>