<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Fotheby’s Auctions| Best Auction Site in Kathmandu|Best estore in nepal</title>
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/price-range.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/css/main.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +977-9842557886</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> info@Fotheby’s.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<!-- <li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li> -->
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->

		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a style = 'font-size:20px' href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/images/logo.jpg')); ?>" /></a>
							<p>Fotheby’s Auction</p>
						</div>
						<div class="btn-group pull-right">
							<div class="btn-group">

							</div>

							<div class="btn-group">

							</div>
						</div>
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">

						<?php
						//favorite products, change password, logout, mycart OR register
						?>

						<?php if(Auth::check()): ?>
							<ul class="nav navbar-nav">


								<li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>

								<li><a href="<?php echo e(url('user/profile/'.Auth::user()->id)); ?>"><i class="fa fa-star"></i> View Profile</a></li>
								<li><a href="<?php echo e(url('user/changepassword')); ?>"><i class="fa fa-lock"></i> Change Password</a></li>

								<li><a href="<?php echo e(url('user/logout')); ?>"><i class="fa fa-lock"></i> Logout</a></li>

							</ul>
						<?php else: ?>
						<ul class="nav navbar-nav">
								<li><a href="<?php echo e(url('user/login')); ?>"><i class="fa fa-lock"></i> Login</a></li>

								<li><a href="<?php echo e(url('user/register')); ?>"><i class="fa fa-lock"></i> Register</a></li>
						</ul>
						<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->

		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">

						<?php
							$menu = get_menu_bar();
							//dd($menu);
						?>
							<ul class="nav navbar-nav collapse navbar-collapse">
							<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if(is_array($value)): ?>
								<?php if(in_array(Request::url(), $value)): ?>
								<li class="dropdown"  ><a class = 'active' href="#"><?php echo e($key); ?><i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                    <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($v); ?>"><?php echo e($k); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <?php else: ?>
                                <li class="dropdown"  ><a href="#"><?php echo e($key); ?><i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                    <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($v); ?>"><?php echo e($k); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <?php endif; ?>

								<?php else: ?>

								<?php if(Request::url() == $value): ?>

								<li><a href="<?php echo e($value); ?>" class = 'active' ><?php echo e($key); ?></a></li>

								<?php else: ?>
								<li><a href="<?php echo e($value); ?>" ><?php echo e($key); ?></a></li>

								<?php endif; ?>

								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</ul>
						</div>
					</div>

					<!-- <div class="col-sm-3">
						<div class="search_box pull-right">
							<input type="button" placeholder="Search" value = 'search'/>
						</div>
					</div> -->



				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
