<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>



	<a class = 'btn btn-primary' href = "<?php echo e(url('product/create')); ?>">Create Product</a>

	<table class = 'table table-striped'>
		<tr>
			<td>Product Code</td>
			<td>Artist Name</td>
			<td>Creation Date</td>
			<td>Auction Date</td>
			<td>Quantity</td>
			<td>Price</td>
			<td>Image</td>
			<td>Added By</td>
			<td>Verified</td>
			<td>Action</td>
		</tr>

		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($c->product_code); ?></td>
			<td><?php echo e($c->artist_name); ?></td>
			<td><?php echo e($c->creation); ?></td>
			<td><?php echo e($c->auction_date); ?></td>
			<td><?php echo e($c->qty); ?></td>
			<td><?php echo e($c->price); ?></td>
			<td><img style = "height:120px; width:auto;' >" src = "<?php echo e(URL::to('/').'/uploads/'.$c->image); ?>"> </td>
			<td><?php echo e($c->sold_by); ?></td>


			<?php if(Auth::user()->user_type == "admin"): ?>
			<?php if($c->is_verified ==0): ?>
                <td><a href="<?php echo e(url('product/verify/'.$c->id)); ?>">Not Verified</a></td>
            <?php else: ?>
                <td><a href="<?php echo e(url('product/verify/'.$c->id)); ?>">Verified</a></td>
            <?php endif; ?>

			<?php else: ?>
			<?php if($c->is_verified ==0): ?>
                <td>Not Verified</td>
            <?php else: ?>
                <td>Verified</td>
            <?php endif; ?>

            <?php endif; ?>

            <?php if(Auth::user()->user_type != "admin" && $c->user_type == "admin"): ?>
            <?php else: ?>
			<td><a style = 'float:left' class = 'btn btn-primary' href = "<?php echo e(url('product/edit/'.$c->id)); ?>">Edit</a> <form action = "<?php echo e(url('product/delete')); ?>" method = 'POST'>
				<input type = 'hidden' name = 'id' value = "<?php echo e($c->id); ?>" />
				<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
				<input type = 'hidden' name = '_method' value = 'DELETE' />
				<input type = 'submit' class = 'btn btn-danger' value = 'Delete' />
			</form></td>
			<?php endif; ?>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<?php echo e($products->links()); ?>





                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>