<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>


<h3>Edit Details</h3>
<form action = "<?php echo e(url('user/edit')); ?>" method = 'POST' enctype="multipart/form-data">
    Full Name : <input type = 'text' name = 'fullname' class = 'form-control' value = "<?php echo e(old('fullname',$user['name'])); ?>" ><br>
    Email : <input type = 'text' name = 'email' class = 'form-control' value = "<?php echo e(old('email',$user['email'])); ?>" ><br>
    Contact : <input type = 'text' name = 'contact' class = 'form-control' value = "<?php echo e(old('contact',$user['contact'])); ?>" ><br>
    Address : <input type = 'text' name = 'address' class = 'form-control' value = "<?php echo e(old('address',$user['address'])); ?>" ><br>
    <img src = "<?php echo e(URL::to('/').'/uploads/'.$user['image']); ?>" height="120px" />
    <br>
    Image(if changing) : <input type = 'file' class = 'form-control' name = 'image' alt="No Image" /><br>
    User Type :
    <select  class = 'form-control' name="userType">
        <option value="admin">Admin</option>
        <option value="Buyer">Buyer</option>
        <option value="Seller">Seller</option>
    </select><br>
    <input type = 'hidden' name = '_token' value="<?php echo e(csrf_token()); ?>">
    <input type = 'submit' class = 'btn btn-primary'/>
    <input type = 'hidden' name = 'id' value = "<?php echo e($user['id']); ?>" />
    <input type = 'hidden' name = '_method' value = 'PUT' />
</form>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>