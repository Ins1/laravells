<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>


                    <a href = "<?php echo e(url('user/create')); ?>" class = 'btn btn-primary
'>Create Users</a>

                    <table class = 'table table-striped'>
                        <tr>
                            <td> Name</td>
                            <td> Email</td>
                            <td> Address</td>
                            <td> Number</td>
                            <td> Type</td>
                            <td> Verified</td>
                            <td>Action</td>
                        </tr>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($c['name']); ?></td>
                            <td><?php echo e($c['email']); ?></td>
                            <td><?php echo e($c['address']); ?></td>
                            <td><?php echo e($c['contact']); ?></td>
                            <td><?php echo e($c['user_type']); ?></td>

                            <?php if(Auth::user()->email == $c['email']): ?>
                                <?php if($c['email_verified'] ==0): ?>
                                <td>Not Verified</td>
                            <?php else: ?>
                                <td>Verified</td>
                            <?php endif; ?>
                            <?php else: ?>
                            <?php if($c['email_verified'] ==0): ?>
                                <td><a href="<?php echo e(url('user/verify/'.$c['id'])); ?>">Not Verified</a></td>
                            <?php else: ?>
                                <td><a href="<?php echo e(url('user/verify/'.$c['id'])); ?>">Verified</a></td>
                            <?php endif; ?>

                            <?php endif; ?>
                            <td><a class = 'btn btn-primary' style = 'float:left' href = "<?php echo e(url('user/edit/'.$c['id'])); ?>">Edit</a>

                                <?php if(Auth::user()->email != $c['email']): ?>
                                <form action = "<?php echo e(url('user/delete')); ?>" method = 'POST'>
                                    <input type = 'hidden' name = 'id' value = "<?php echo e($c['id']); ?>" />
                                    <input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
                                    <input type = 'hidden' name = '_method' value = 'DELETE' />
                                    <input type = 'submit' value = 'Delete' class = 'btn btn-danger'/>
                                </form>
                                <?php endif; ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo e($users->links()); ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>