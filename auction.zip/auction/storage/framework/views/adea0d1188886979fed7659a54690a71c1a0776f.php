<?php $__env->startSection('content'); ?>
<section id="slider"><!--slider-->

<?php //slider contains featured products that have images in descending order no 3?>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<?php $__currentLoopData = $featured_products_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($key == 0): ?>
							<li data-target="#slider-carousel" data-slide-to="<?php echo e($key); ?>" class="active"></li>
							<?php else: ?>

							<li data-target="#slider-carousel" data-slide-to="<?php echo e($key); ?>"></li>
							<?php endif; ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</ol>

						<div class="carousel-inner">

							<?php $__currentLoopData = $featured_products_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php if($key == 0): ?>
							<div class="item active">
								<div class="col-sm-6">
									<h1><?php echo e($value['product_code']); ?></h1>
									<h2>Rs. <?php echo e($value['price']); ?></h2>

<!--									<button type="button" class="btn btn-default get">Get it now</button>-->
								</div>
								<div class="col-sm-6">
									<img src="<?php echo e(asset('uploads/'.$value['image'])); ?>" class="girl img-responsive" alt="" />
									<img src="images/home/pricing.png"  class="pricing" alt="" />
								</div>
							</div>
							<?php else: ?>

							<div class="item">
								<div class="col-sm-6">
									<h1><?php echo e($value['product_code']); ?></h1>
									<h2>Rs. <?php echo e($value['price']); ?></h2>

<!--									<button type="button" class="btn btn-default get">Get it now</button>-->
								</div>
								<div class="col-sm-6">
									<img src="<?php echo e(asset('uploads/'.$value['image'])); ?>" class="girl img-responsive" alt="" />
									<img src="images/home/pricing.png"  class="pricing" alt="" />
								</div>
							</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>

						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>

				</div>
			</div>
		</div>
	</section><!--/slider-->

	<section>
		<div class="container">
			<div class="row">
				<?php echo $__env->make('layouts.front.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Upcoming Items</h2>

						<?php $__currentLoopData = $featured_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">

								<?php //featured items contain products that are featured 6 ?>
										<div class="productinfo text-center">
											<img src="<?php echo e(asset('uploads/'.$value['image'])); ?>" alt="" />
											<h2>Rs. <?php echo e($value['price']); ?></h2>
											<p><?php echo e($value['product_code']); ?></p>
<!--											<?php if(Auth::check()): ?>-->
<!--											<a href="<?php echo e(url('cart/add/'.$value['id'])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>-->
<!--											<?php endif; ?>-->
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>Rs. <?php echo e($value['price']); ?></h2>
												<p><?php echo e($value['product_code']); ?> </p>
                                                <a href="<?php echo e(url('product/'.$value['id'])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-plus"></i>View Details</a>
<!--												<?php if(Auth::check()): ?>-->
<!--												<a href="<?php echo e(url('cart/add/'.$value['id'])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>-->
<!--												<?php endif; ?>-->
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
<!--									<?php if(Auth::check()): ?>-->
<!--										<li><a href="<?php echo e(url('wishlist/add/'.$value['id'])); ?>"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>-->
<!--									<?php endif; ?>-->
									</ul>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div><!--features_items-->


					<?php //categorywise products 4 for each category?>
					<div class="category-tab"><!--category-tab-->
						<div class="col-sm-12">
							<ul class="nav nav-tabs">

							<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php if($key == 0): ?>
								<li class="active"><a href="#<?php echo e($value['id']); ?>" data-toggle="tab"><?php echo e($value['category_name']); ?> </a></li>
							<?php else: ?>
								<li><a href="#<?php echo e($value['id']); ?>" data-toggle="tab"><?php echo e($value['category_name']); ?> </a></li>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
						<div class="tab-content">

							<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($key == 0): ?>
							<div class="tab-pane fade active in" id="<?php echo e($value['id']); ?>">
							<?php $__currentLoopData = $value->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($v['is_verified'] == 1): ?>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="<?php echo e(asset('uploads/'.$v['image'])); ?>" alt="" />
												<h2>Rs. <?php echo e($v['price']); ?></h2>
												<p><?php echo e($v['product_code']); ?></p>
							
<!--												<?php if(Auth::check()): ?>-->
<!--												<a href="<?php echo e(url('cart/add/'.$v['id'])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>-->
<!--												<?php endif; ?>-->
											</div>

										</div>
									</div>
								</div>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<?php else: ?>
							<div class="tab-pane fade in" id="<?php echo e($value['id']); ?>">

							<?php $__currentLoopData = $value->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($v['is_verified'] == 1): ?>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="<?php echo e(asset('uploads/'.$v['image'])); ?>" alt="" />
												<h2>Rs. <?php echo e($v['price']); ?></h2>
												<p><?php echo e($v['product_code']); ?></p>
<!--												<?php if(Auth::check()): ?>-->
<!--												<a href="<?php echo e(url('cart/add/'.$v['id'])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>-->
<!--												<?php endif; ?>-->
											</div>

										</div>
									</div>
								</div>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
					</div><!--/category-tab-->


				</div>
			</div>
		</div>
	</section>
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>