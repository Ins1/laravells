<div class="col-sm-3">
					<div class="left-sidebar">

					<?php
					$sidebar  = get_sidebar();
					 //pull the data of categories all ?>
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->

							<?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="<?php echo e($value); ?>"><?php echo e($key); ?></a></h4>
								</div>
							</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div><!--/category-products-->

					<?php //create a form to make advanced filter that can search from multiple parameter?>
						<div class="price-range"><!--price-range-->

						<form action = "<?php echo e(url('searchproduct')); ?>" method = 'GET'>
							<h2>Search</h2>
							<div class="well text-center">
							<p>Artist Name</p>

							<?php if(\Request::has('pname')): ?>
							<?php
							$pname = \Request::get('pname');
							?>
							<?php else: ?>
							<?php
							$pname = '';
							?>
							<?php endif; ?>

							<input type = 'text' class = 'form-control' name = 'pname' value = "<?php echo e($pname); ?>"/>
							<br>

							<?php
							$categories = array();
							?>

							<?php if(\Request::has('categories')): ?>
							<?php
							$categories = \Request::get('categories');
							?>
							<?php endif; ?>

							<p>Categories</p>
							<select name = 'categories[]' class = 'form-control' multiple>
							<?php $__currentLoopData = get_categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value = "<?php echo e($v['id']); ?>" <?php if(in_array($v['id'],$categories)): ?> selected <?php endif; ?>><?php echo e($v['category_name']); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select><br/>

							<?php if(\Request::has('pricerange')): ?>
							<?php
							$pricerange = \Request::get('pricerange');
							?>
							<?php else: ?>
							<?php
							$pricerange = "10000,200000";
							?>
							<?php endif; ?>
							<p>Price Range</p>
							 <input name = 'pricerange' type="text" class="span2" value="<?php echo e($pricerange); ?>" data-slider-min="10000" data-slider-max="200000" data-slider-step="5" data-slider-value="[<?php echo e($pricerange); ?>]" id="sl2" ><br />
								 <b class="pull-left">Rs 10000</b> <b class="pull-right">Rs 200000</b>
								<br/>
							<p>Order By Price</p>
							<br>

							<?php if(\Request::has('orderprice')): ?>
							<?php
							$orderprice = \Request::get('orderprice');
							?>
							<?php else: ?>
							<?php
							$orderprice = 'asc';
							?>
							<?php endif; ?>

							<select name = 'orderprice'>
								<option value = 'asc'<?php if($orderprice == 'asc'): ?> selected <?php endif; ?>>Lowest First</option>
								<option value = 'desc' <?php if($orderprice == 'desc'): ?> selected <?php endif; ?>>Highest First</option>
							</select>
							<br><br>
							<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
							<input type = 'submit' class = 'btn btn-success' value = 'Search' />
							</div>

						</form>
						</div><!--/price-range-->

						<div class="shipping text-center"><!--shipping-->
							<img src="images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->

					</div>
				</div>
