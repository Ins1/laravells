<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Orders</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                <form action = "<?php echo e(url('order/searchorder')); ?>" method="POST">
	Status : <select name = 'status' class = 'form-control'>
				<option value = 'pending'>Pending</option>
				<option value = 'delivered'>Delivered</option>
				<option value = 'cancelled'>Cancelled</option>
			</select>
			<br>
			<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
			
			<input type = 'submit' class = 'btn btn-primary' value = 'Search'/>

			<a class = 'btn btn-success' href = "<?php echo e(url('order/view')); ?>">Clear Filter</a>

	</form>
<br>

	<table class = 'table table-striped'>
		<tr>
			<td>Name</td>
			<td>Phone</td>
			<td>Email</td>
			<td>Address</td>
			<td>User Email</td>
			<td>User Name</td>
			<td>Delivery Location</td>
			<td>Created Date</td>
			<td>Status</td>
			<td>Action</td>
		</tr>

		<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($c['name']); ?></td>
			<td><?php echo e($c['phone']); ?></td>
			<td><?php echo e($c['email']); ?></td>
			<td><?php echo e($c['address']); ?></td>
			<td><?php echo e($c->user['name']); ?></td>
			<td><?php echo e($c->user['email']); ?></td>
			<td><?php echo e($c['location']); ?></td>
			<td><?php echo e($c['created_at']); ?></td>
			<td><?php echo e($c['status']); ?></td>
			<td><a style = 'float:left' class = 'btn btn-primary' href = "<?php echo e(url('order/viewdetail/'.$c['id'])); ?>">View Detail</a></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<?php echo e($orders->links()); ?>





                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>