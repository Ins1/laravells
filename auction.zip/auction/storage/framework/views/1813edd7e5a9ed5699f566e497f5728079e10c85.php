<?php echo $__env->make('layouts.front.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
	
	<section>
		<div class="container">
			<div class="row">
			<?php if(\Session::has('msg')): ?>
	<div class = 'alert alert-success'>
		<p><?php echo e(\Session::get('msg')); ?></p>
	</div></br>
	<?php endif; ?>
				<?php echo $__env->make('layouts.front.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				
				<div class="col-sm-9">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
			</div>
		</div>
	</section>
	
	<?php echo $__env->make('layouts.front.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>