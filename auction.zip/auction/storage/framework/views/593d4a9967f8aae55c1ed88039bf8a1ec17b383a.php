<?php $__env->startSection('content'); ?>

<div class="product-details"><!--product-details-->
<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-sm-5">
							<div class="view-product">
								<img src="<?php echo e(asset('uploads/'.$pro->image)); ?>" alt="" />

							</div>


						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->

								<h2><b>Code:</b> <?php echo e($pro->product_code); ?></h2>
                                <h4><b>Artist Name:</b> <?php echo e($pro->artist_name); ?></h4>


								<span>

									<span >Rs. <?php echo e($pro->price); ?></span>



								</span>
                                <p><b>Date of Creation:</b> <?php echo e($pro->creation); ?></p>
                                <p><b>Date of Auction:</b> <?php echo e($pro->auction_date); ?></p>
								<p><b>Qty:</b> <?php echo e($pro->qty); ?></p>
                                <p><b>Seller:</b><a href="<?php echo e(url('user/profile/'.$pro->id)); ?>"><?php echo e($pro->sold_by); ?></a></p>
                                <p><b>Dimensions:</b><?php echo e($pro->dimensions); ?></p>
                                <p><b>Weight:</b><?php echo e($pro->weight); ?></p>
                                <p><b>Materials:</b><?php echo e($pro->materials); ?></p>
                                <p><b>Medium:</b><?php echo e($pro->medium); ?></p>
                                <p><b>Type:</b><?php echo e($pro->type); ?></p>
                                 <?php if($pro->auction_date < date('Y-m-d')): ?>
                                                <p><b>Status: </b><span style="color: red">Closed</span></p>
                                        <?php else: ?>
                                        <p><b>Status: </b><span style="color: blue">Open</span></p>
                                        <?php endif; ?>
                               
								<p class = 'showmore' style = 'overflow:hidden; height: 100px;'><b>Detail:</b> <?php echo e($pro->detail); ?></p>
								<a style = 'cursor:pointer' class = 'readmore'>Read More</a>

                                  

							</div><!--/product-information-->
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div><!--/product-details-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>