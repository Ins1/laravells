<?php
/**
 * Created by IntelliJ IDEA.
 * User: Dell
 * Date: 4/30/2019
 * Time: 4:36 PM
 */

namespace App\Http\Controllers;
use Illuminate\Http\Request;

class UserController extends Controller
{
    function __construct()
    {
        $this->middleware('admin');
    }

    public function view()
    {
        //select the data from table
        $users = \App\User::paginate(3);
        return view('user/all',compact('users'));
    }

    public function delete(Request $r)
    {
        $id = $r->get('id');
        $user = \App\User::find($id);
        $user->delete($id);
        return redirect('users/view')->with('msg','Deleted Successfully');
    }

    public function edit($id)
    {
        $user = \App\User::find($id);
        return view('user/edit',compact('user'));
    }

    public function update(Request $r){


        $validations = array(
            'fullname' => 'required|min:2',
            'email' => 'email|required',
            'contact' => 'required|max:15',
            'address' => 'required',
            'image' => 'mimes:jpeg,bmp,png,gif|max:800'

        );

        $r->validate($validations);
        $id = $r->get('id');
        $user = \App\User::find($id);

        if($r->hasFile('image'))
        {

            $file = $r->file('image');
            $name = date('ymdhis').$file->getClientOriginalName();
            $path = public_path().'/uploads/';
            $file->move($path,$name);

            $user->image = $name;
        }

        $user->name= $r->get('fullname');
        $user->email= $r->get('email');
         $user->user_type= $r->get('userType');
        $user->contact= $r->get('contact');
        $user->address= $r->get('address');
        $user->save();
        return redirect('user/edit/'.$id)->with('msg','User has been Updated');
    }

    public function create(){
        return view('user/create');
    }

    public function store(Request $r){

        $v = array(
            'fullname' => 'required|min:2',
            'email' => 'email|required|unique:users',
            'password' => 'required|confirmed|min:6',
            'contact' => 'required|max:15',
            'address' => 'required',
            'image' => 'mimes:jpeg,bmp,png,gif|max:800'

        );
        $r->validate($v);
        $name = '';
        if($r->hasfile('image'))
        {
            $file = $r->file('image');
            $name = date('ymdhis').$file->getClientOriginalName();
            $path = public_path().'/uploads/';
            $file->move($path, $name);
        }
        $data['name'] = $r->get('fullname');
        $data['email'] = $r->get('email');
        $data['password'] = bcrypt($r->get('password'));
        $data['user_type'] = $r->get('userType');
        $data['contact'] = $r->get('contact');
        $data['address'] = $r->get('address');
        $data['image'] = $name;

         \App\User::create($data);
        return redirect('/user/create')->with('msg','Addition Succesful');

    }

    public function verify($id){
        $user = \App\User::find($id);
        if($user->email_verified == 0){
            $user->email_verified = 1;
            $user->save();
        }else if($user->email_verified == 1){
            $user->email_verified = 0;
            $user->save();
        }
        return redirect('/users/view')->with('msg','Verified Success');
    }

}
