<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use File;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    function __construct()
    {
        $this->middleware('admin');
    }

    public function create()
    {
    	$categories = \App\Category::all();
    	return view('product/create',compact('categories'));
    }

    public function store(Request $request)
    {
    	//validations
    	$validations = array(
    		'pcode' => 'required|max:8',
    		'aname' => 'required',
    		'cdate' => 'required',
    		'audate' => 'required',
    		'qty' => 'required|integer',
    		'price' => 'required',
    		'image' => 'mimes:jpeg,bmp,png,gif|max:800'
    	);
    	$name = '';
    	$request->validate($validations);
		if($request->hasfile('image'))
    	{
    		$file = $request->file('image');
    		$name = date('ymdhis').$file->getClientOriginalName();
    		$path = public_path().'/uploads/';
    		$file->move($path, $name);
    	}
    	//image size validation, image type validation
    	$product = new \App\Product;
    	$product->artist_name = $request->get('aname');
    	$product->product_code = $request->get('pcode');
    	$product->creation = $request->get('cdate');
    	$product->auction_date = $request->get('audate');
    	$product->qty = $request->get('qty');
    	$product->price = $request->get('price');
    	$product->image = $name;
    	$product->detail = $request->get('detail');
    	$product->dimensions = $request->get('dimensions');
    	$product->weight = $request->get('weigth') == "" ? null : $request->get('weigth');
    	$product->materials = $request->get('materials');
    	$product->medium = $request->get('medium');
    	$product->type = $request->get('type');
    	$product->is_featured = $request->get('featured');
    	$product->category_id = $request->get('categoryid');
    	$product->sold_by = $request->get('usernam');
    	$product->save();
    	return redirect('/product/create')->with('msg','Product Created Successfully');
    }

    public function view()
    {
        $products = DB::table('products')
            ->join('users', 'products.sold_by', '=', 'users.name')
            ->select('products.*','users.user_type')
            ->paginate(3);
    	
    	return view('product/all',compact('products'));
    }

    public function edit($id)
    {
        $categories = \App\Category::all();
        $product = \App\Product::find($id);
        return view('product/edit',compact('categories','product'));
    }

    public function update(Request $r)
    {
        //validation
        $validations = array(
            'pcode' => 'required|max:8',
            'aname' => 'required',
            'cdate' => 'required',
            'audate' => 'required',
            'qty' => 'required|integer',
            'price' => 'required',
            'image' => 'mimes:jpeg,bmp,png,gif|max:800'
        );
        $id = $r->get('id');
        $r->validate($validations);
        $product = \App\Product::find($id);
        if($r->hasFile('image'))
        {
            $file = $r->file('image');
            $name = date('ymdhis').$file->getClientOriginalName();
            $path = public_path().'/uploads/';
            $file->move($path,$name);

            $product->image = $name;
        }

        $product->artist_name = $r->get('aname');
        $product->product_code = $r->get('pcode');
        $product->creation = $r->get('cdate');
        $product->auction_date = $r->get('audate');
        $product->qty = $r->get('qty');
        $product->price = $r->get('price');
        $product->detail = $r->get('detail');
        $product->dimensions = $r->get('dimensions');
        $product->weight = $r->get('weigth');
        $product->materials = $r->get('materials');
        $product->medium = $r->get('medium');
        $product->type = $r->get('type');
        $product->is_featured = $r->get('featured');
        $product->category_id = $r->get('categoryid');
        $product->sold_by = $r->get('usernam');
        $product->save();
        return redirect('product/edit/'.$id)->with('msg','Product Updated Successfully');
        //save the record
    }

    public function delete(Request $r)
    {
        $id = $r->get('id');
        $product = \App\Product::find($id);
        $image_path = public_path()."/uploads/".$product['image'];
        if(File::exists($image_path)) {
        File::delete($image_path);
        }
        $product->delete();
        return redirect('product/read')->with('msg','Product Removed');
    }

    public function verify($id){
        $product = \App\Product::find($id);
        if($product->is_verified == 0){
            $product->is_verified = 1;
            $product->save();
        }else if($product->is_verified == 1){
            $product->is_verified = 0;
            $product->save();
        }
        return redirect('/product/read')->with('msg','Verified Success');
    }

}
