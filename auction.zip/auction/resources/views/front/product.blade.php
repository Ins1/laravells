@extends('layouts.front.default')

@section('content')

<div class="product-details"><!--product-details-->
@foreach($product as $pro)
						<div class="col-sm-5">
							<div class="view-product">
								<img src="{{ asset('uploads/'.$pro->image)}}" alt="" />

							</div>


						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->

								<h2><b>Code:</b> {{ $pro->product_code }}</h2>
                                <h4><b>Artist Name:</b> {{$pro->artist_name}}</h4>


								<span>

									<span >Rs. {{ $pro->price }}</span>



								</span>
                                <p><b>Date of Creation:</b> {{ $pro->creation }}</p>
                                <p><b>Date of Auction:</b> {{ $pro->auction_date }}</p>
								<p><b>Qty:</b> {{ $pro->qty }}</p>
                                <p><b>Seller:</b><a href="{{ url('user/profile/'.$pro->id) }}">{{ $pro->sold_by }}</a></p>
                                <p><b>Dimensions:</b>{{ $pro->dimensions }}</p>
                                <p><b>Weight:</b>{{ $pro->weight }}</p>
                                <p><b>Materials:</b>{{ $pro->materials }}</p>
                                <p><b>Medium:</b>{{ $pro->medium }}</p>
                                <p><b>Type:</b>{{ $pro->type }}</p>
                                 @if($pro->auction_date < date('Y-m-d'))
                                                <p><b>Status: </b><span style="color: red">Closed</span></p>
                                        @else
                                        <p><b>Status: </b><span style="color: blue">Open</span></p>
                                        @endif
                               
								<p class = 'showmore' style = 'overflow:hidden; height: 100px;'><b>Detail:</b> {{ $pro->detail }}</p>
								<a style = 'cursor:pointer' class = 'readmore'>Read More</a>

                                  

							</div><!--/product-information-->
						</div>
						@endforeach
					</div><!--/product-details-->


@endsection
