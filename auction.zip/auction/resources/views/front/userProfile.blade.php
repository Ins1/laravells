@extends('layouts.front.default')

@section('content')
<div class="product-details"><!--product-details-->
    <div class="col-sm-5">
        <div class="view-product">
            <img src="{{ asset('uploads/'.$user['image'])}}" alt="" />

        </div>


    </div>
    <div class="col-sm-7">
        <div class="product-information"><!--/product-information-->

            <h2><b>Name:</b> {{ $user['name'] }}</h2>
            <h4><b>Email:</b> {{$user['email']}}</h4>
            <h4><b>User Type:</b> {{$user['user_type']}}</h4>
            <h4><b>Address:</b> {{$user['address']}}</h4>
            <h4><b>Contact Number:</b> {{$user['contact']}}</h4>





        </div><!--/product-information-->
    </div>
</div><!--/product-details-->


@endsection

