<h1>Hello from bisalcommerce</h1>
<p>{{ $msg }}</p>