@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif



	<a class = 'btn btn-primary' href = "{{ url('product/create') }}">Create Product</a>

	<table class = 'table table-striped'>
		<tr>
			<td>Product Code</td>
			<td>Artist Name</td>
			<td>Creation Date</td>
			<td>Auction Date</td>
			<td>Quantity</td>
			<td>Price</td>
			<td>Image</td>
			<td>Added By</td>
			<td>Verified</td>
			<td>Action</td>
		</tr>

		@foreach($products as $c)
		<tr>
			<td>{{ $c->product_code }}</td>
			<td>{{ $c->artist_name }}</td>
			<td>{{ $c->creation }}</td>
			<td>{{ $c->auction_date }}</td>
			<td>{{ $c->qty }}</td>
			<td>{{ $c->price }}</td>
			<td><img style = "height:120px; width:auto;' >" src = "{{ URL::to('/').'/uploads/'.$c->image }}"> </td>
			<td>{{$c->sold_by}}</td>


			@if(Auth::user()->user_type == "admin")
			@if($c->is_verified ==0)
                <td><a href="{{url('product/verify/'.$c->id)}}">Not Verified</a></td>
            @else
                <td><a href="{{url('product/verify/'.$c->id)}}">Verified</a></td>
            @endif

			@else
			@if($c->is_verified ==0)
                <td>Not Verified</td>
            @else
                <td>Verified</td>
            @endif

            @endif

            @if(Auth::user()->user_type != "admin" && $c->user_type == "admin")
            @else
			<td><a style = 'float:left' class = 'btn btn-primary' href = "{{ url('product/edit/'.$c->id) }}">Edit</a> <form action = "{{ url('product/delete') }}" method = 'POST'>
				<input type = 'hidden' name = 'id' value = "{{ $c->id }}" />
				<input type = 'hidden' name = '_token' value = '{{ csrf_token() }}' />
				<input type = 'hidden' name = '_method' value = 'DELETE' />
				<input type = 'submit' class = 'btn btn-danger' value = 'Delete' />
			</form></td>
			@endif
		</tr>
		@endforeach
	</table>
	{{ $products->links() }}




                </div>
            </div>
        </div>
    </div>
</div>
@endsection


