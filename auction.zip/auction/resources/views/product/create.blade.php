@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif


<h3>Add a New Product</h3>

<form action = "{{ url('product/create') }}" method = 'POST' enctype="multipart/form-data">
    Product Code : <input type = 'text' class = 'form-control' name = 'pcode' value = "{{ old('pcode') }}" /><br>
	Artist name : <input type = 'text' class = 'form-control' name = 'aname' value = "{{ old('aname') }}" /><br>
	Created Date : <input type = 'date' class = 'form-control' name = 'cdate' value = "{{ old('cdate') }}" /><br>
	Auction Date : <input type = 'date' class = 'form-control' name = 'audate' value = "{{ old('audate') }}" /><br>
	Qty : <input type = 'text' class = 'form-control' name = 'qty' value = "{{ old('qty') }}"/><br>
	Price : <input type = 'text' class = 'form-control' name = 'price' value = "{{ old('price') }}"/><br>
	Image : <input type = 'file' class = 'form-control' name = 'image' /><br>

	Choose Category : <select class = 'form-control' name = 'categoryid' id="categoryid" onchange="applyFilter()">
		@foreach($categories as $value)
		<option value="{{ $value['id'] }}" @if(old('categoryid') == $value['id']) selected @endif>{{ $value['category_name'] }}</option>
		@endforeach
	</select><br>
    <p id="featured" hidden>Is Framed : Yes<input type = 'radio' name = 'featured' value = 'yes' @if(old('featured') == 'yes') checked @endif/>
        No<input type = 'radio' name = 'featured' value = 'no' @if(old('featured') == 'no') checked @endif/>
        <br><br></p>
    <p id="dimensions" hidden>Dimensions : <input type = 'text' class = 'form-control'  name = 'dimensions' value = "{{ old('dimensions') }}"/><br></p>
    <p id="weigth" hidden>Weigth : <input type = 'text' class = 'form-control'  name = 'weigth' value = "{{ old('weigth') }}"/><br></p>
    <p id="materials" hidden>Materials : <input type = 'text' class = 'form-control' name = 'materials' value = "{{ old('materials') }}"/><br></p>
    <p id="medium" hidden>Medium : <input type = 'text' class = 'form-control'   name = 'medium' value = "{{ old('medium') }}"/><br></p>
    <p id="type" hidden> Type : <input type = 'text' class = 'form-control'  name = 'type' value = "{{ old('type') }}"/><br></p>
    Detail : <textarea class = 'form-control' name = 'detail'>{{ old('detail') }}</textarea><br>
    <input type = 'hidden' name = 'usernam' value = '{{ Auth::user()->name }}' />
	<input type = 'hidden' name = '_token' value = '{{ csrf_token() }}' />
	<input type = 'submit' class = 'btn btn-primary' />

</form>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

    applyFilter();
    $("#categoryid").trigger('change');



    function applyFilter(){

        var value = $('#categoryid').val();
        if(value != null){
            if(value == 6 || value == 7){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden",false);
                $('#featured').prop("hidden",false);
                $('#type').prop("hidden","hidden");
                $('#weigth').prop("hidden","hidden");
                $('#materials').prop("hidden","hidden");
            }else if(value == 9){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden","hidden");
                $('#featured').prop("hidden","hidden");
                $('#type').prop("hidden",false);
                $('#weigth').prop("hidden","hidden");
                $('#materials').prop("hidden","hidden");
            }else if(value == 8 || value == 10){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden","hidden");
                $('#featured').prop("hidden","hidden");
                $('#type').prop("hidden","hidden");
                $('#weigth').prop("hidden",false);
                $('#materials').prop("hidden",false);
            }
        }
    }

</script>
@endsection
