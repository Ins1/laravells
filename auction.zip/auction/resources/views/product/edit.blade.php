@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif



<h3>Add a New Product</h3>

<form action = "{{ url('product/edit') }}" method = 'POST' enctype="multipart/form-data">

	Product Code : <input type = 'text' class = 'form-control' name = 'pcode' value = "{{ old('pcode',$product['product_code']) }}" /><br>
	Artist Name : <input type = 'text' class = 'form-control' name = 'aname' value = "{{ old('aname',$product['artist_name']) }}" /><br>
    Created Date : <input type = 'date' class = 'form-control' name = 'cdate' value = "{{ old('cdate',$product['creation']) }}" /><br>
    Auction Date : <input type = 'date' class = 'form-control' name = 'audate' value = "{{ old('audate',$product['auction_date']) }}" /><br>
	Qty : <input type = 'text' name = 'qty' class = 'form-control' value = "{{ old('qty',$product['qty']) }}"/><br>

	Price : <input type = 'text' name = 'price' class = 'form-control' value = "{{ old('price',$product['price']) }}"/><br>


	<img src = "{{ URL::to('/').'/uploads/'.$product['image'] }}" height="120px" />
	<br>

	Image(if changing) : <input type = 'file' class = 'form-control' name = 'image' /><br>

	Choose Category : <select class = 'form-control' name = 'categoryid' id="categoryid" onchange="applyFilter()">
		@foreach($categories as $value)
		<option value="{{ $value['id'] }}" @if(old('categoryid',$product['category_id']) == $value['id']) selected @endif>{{ $value['category_name'] }}</option>
		@endforeach
	</select><br>

    <p id="featured" hidden>Is Framed : Yes<input type = 'radio' name = 'featured' value = 'yes' @if(old('featured',$product['is_featured']) == 'yes') checked @endif/>
        No<input type = 'radio' name = 'featured' value = 'no' @if(old('featured',$product['is_featured']) == 'no') checked @endif/>
        <br><br></p>
    <p id="dimensions" hidden>Dimensions : <input type = 'text' class = 'form-control'  name = 'dimensions' value = "{{ old('dimensions',$product['dimensions']) }}"/><br></p>
    <p id="weigth" hidden>Weigth : <input type = 'text' class = 'form-control'  name = 'weigth' value = "{{ old('weigth',$product['weight']) }}"/><br></p>
    <p id="materials" hidden>Materials : <input type = 'text' class = 'form-control' name = 'materials' value = "{{ old('materials',$product['materials']) }}"/><br></p>
    <p id="medium" hidden>Medium : <input type = 'text' class = 'form-control'   name = 'medium' value = "{{ old('medium',$product['medium']) }}"/><br></p>
    <p id="type" hidden> Type : <input type = 'text' class = 'form-control'  name = 'type' value = "{{ old('type',$product['type']) }}"/><br></p>

	Detail : <textarea class = 'form-control' name = 'detail'>{{ old('detail',$product['detail']) }}</textarea><br>
	<input type = 'hidden' name = '_token' value = '{{ csrf_token() }}' />
	<input type = 'hidden' name = 'id' value = "{{ $product['id']}}" />
    <input type = 'hidden' name = 'usernam' value = '{{ Auth::user()->name }}' />
	<input type = 'hidden' name = '_method' value = 'PUT' />
	<input type = 'submit' class = 'btn btn-primary'/>

</form>

                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

    applyFilter();
    $("#categoryid").trigger('change');



    function applyFilter(){

        var value = $('#categoryid').val();
        if(value != null){
            if(value == 6 || value == 7){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden",false);
                $('#featured').prop("hidden",false);
                $('#type').prop("hidden","hidden");
                $('#weigth').prop("hidden","hidden");
                $('#materials').prop("hidden","hidden");
            }else if(value == 9){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden","hidden");
                $('#featured').prop("hidden","hidden");
                $('#type').prop("hidden",false);
                $('#weigth').prop("hidden","hidden");
                $('#materials').prop("hidden","hidden");
            }else if(value == 8 || value == 10){
                $('#dimensions').prop("hidden",false);
                $('#medium').prop("hidden","hidden");
                $('#featured').prop("hidden","hidden");
                $('#type').prop("hidden","hidden");
                $('#weigth').prop("hidden",false);
                $('#materials').prop("hidden",false);
            }
        }
    }

</script>
@endsection











