@extends('layouts.front.default')

@section('content')


	@if(\Session::has('msg'))
	<div class = 'alert alert-success'>
		<p>{{ \Session::get('msg') }}</p>
	</div></br>
	@endif

	@if($errors->any())
	<div class = 'alert alert-danger'>
		<ul>
			@foreach($errors->all() as $e)
			<li>{{ $e }}</li>
			@endforeach
		</ul>
	</div>
	@endif

<h3>Registration Form</h3>
<form action = "{{ url('user/register') }}" method = 'POST' enctype="multipart/form-data">
	Full Name : <input type = 'text' name = 'fullname' class = 'form-control' value = "{{ old('fullname') }}" ><br>
	Email : <input type = 'text' name = 'email' class = 'form-control' value = "{{ old('email') }}" ><br>
	Contact : <input type = 'text' name = 'contact' class = 'form-control' value = "{{ old('contact') }}" ><br>
	Address : <input type = 'text' name = 'address' class = 'form-control' value = "{{ old('address') }}" ><br>
	Image : <input type = 'file' name = 'image' class = 'form-control' ><br>
	Password : <input type = 'password' name = 'password' class = 'form-control' ><br>
	Confirm Password : <input type = 'password' name = 'password_confirmation' class = 'form-control' ><br>
	User Type :
    <select  class = 'form-control' name="userType">
       
        <option value="Buyer">Buyer</option>
        <option value="Seller">Seller</option>
    </select><br>
	<input type = 'hidden' name = '_token' value="{{ csrf_token() }}">
	<input type = 'submit' class = 'btn btn-primary'/>
</form>

@endsection
